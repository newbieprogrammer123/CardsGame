﻿namespace NueGames.NueDeck.Scripts.Characters.Enemies
{
    public class EnemyExample : EnemyBase
    {
        
    }
}