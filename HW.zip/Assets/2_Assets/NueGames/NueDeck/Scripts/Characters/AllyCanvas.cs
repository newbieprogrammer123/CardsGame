﻿namespace NueGames.NueDeck.Scripts.Characters
{
    public class AllyCanvas : CharacterCanvas
    {
        
    }
}