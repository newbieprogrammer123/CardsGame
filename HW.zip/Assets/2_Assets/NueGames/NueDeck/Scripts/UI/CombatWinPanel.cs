﻿using UnityEngine;

namespace NueGames.NueDeck.Scripts.UI
{
    public class CombatWinPanel : MonoBehaviour
    {
        
    }
}