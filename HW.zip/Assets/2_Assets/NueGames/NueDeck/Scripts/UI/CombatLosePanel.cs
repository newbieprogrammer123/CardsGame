﻿using UnityEngine;

namespace NueGames.NueDeck.Scripts.UI
{
    public class CombatLosePanel : MonoBehaviour
    {
        
    }
}