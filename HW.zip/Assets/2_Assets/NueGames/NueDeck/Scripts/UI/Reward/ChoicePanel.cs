using UnityEngine;

namespace NueGames.NueDeck.Scripts.UI.Reward
{
    public class ChoicePanel : MonoBehaviour
    {
        public void DisablePanel()
        {
            gameObject.SetActive(false);
        }
    }
}
