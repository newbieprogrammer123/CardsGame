﻿namespace NueGames.NueDeck.Scripts.Card
{
    public class CardUI : CardBase
    {
        
    }
}