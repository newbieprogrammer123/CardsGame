﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum RarityType
    {
        Common,
        Rare,
        Legendary
    }
}