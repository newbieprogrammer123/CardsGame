﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum BackgroundTypes
    {
        Profile1,
        Profile2,
        Profile3
    }
}