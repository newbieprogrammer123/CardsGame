﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum InventoryTypes
    {
        CurrentDeck,
        DrawPile,
        DiscardPile,
        ExhaustPile
    }
}