﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum RewardType
    {
        Gold,
        Card,
        Relic
    }
}