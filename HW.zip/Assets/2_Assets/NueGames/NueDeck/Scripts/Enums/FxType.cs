﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum FxType
    {
        Attack,
        Heal,
        Poison,
        Block,
        Str,
        Buff,
        Stun
    }
}