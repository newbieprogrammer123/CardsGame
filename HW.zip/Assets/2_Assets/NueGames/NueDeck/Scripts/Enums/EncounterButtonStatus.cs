﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum EncounterButtonStatus
    {
        Active,
        Passive,
        Completed
    }
}