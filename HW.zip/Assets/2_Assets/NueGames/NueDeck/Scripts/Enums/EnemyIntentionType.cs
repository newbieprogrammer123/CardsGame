﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum EnemyIntentionType
    {
        Attack,
        Defend,
        Heal,
        Debuff,
        Special
    }
}