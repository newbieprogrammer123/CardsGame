﻿namespace NueGames.NueDeck.Scripts.Enums
{ 
    public enum EnemyActionType
    {
        Attack,
        Heal,
        Poison,
        Block
    }
}