﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum SpecialKeywords
    {
        Block,
        Strength,
        Poison,
        Exhaust,
        Dexterity,
        Stun
    }
}