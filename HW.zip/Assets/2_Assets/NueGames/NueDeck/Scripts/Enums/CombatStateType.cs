﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum CombatStateType
    {
        PrepareCombat,
        AllyTurn,
        EnemyTurn,
        EndCombat
    }
}