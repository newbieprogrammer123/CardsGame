﻿namespace NueGames.NueDeck.Scripts.Enums
{
    public enum CharacterType
    {
        Ally,
        Enemy
    }
}