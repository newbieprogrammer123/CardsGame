﻿using UnityEngine;

namespace NueGames.NueDeck.Scripts.Data.Characters
{
    [CreateAssetMenu(fileName = "Ally Character Data ",menuName = "NueDeck/Characters/Ally",order = 0)]
    public class AllyCharacterData : CharacterDataBase
    {
        
    }
}