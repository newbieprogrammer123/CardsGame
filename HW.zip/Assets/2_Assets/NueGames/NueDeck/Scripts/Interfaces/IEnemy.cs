﻿namespace NueGames.NueDeck.Scripts.Interfaces
{
    public interface IEnemy : ICharacter
    {
       
    }
}