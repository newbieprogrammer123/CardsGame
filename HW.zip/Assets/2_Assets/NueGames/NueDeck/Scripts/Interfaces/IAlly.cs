﻿namespace NueGames.NueDeck.Scripts.Interfaces
{
    public interface IAlly : ICharacter
    {
       
    }
}