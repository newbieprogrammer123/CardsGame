﻿namespace NueGames.NueDeck.ThirdParty.NueTooltip.Interfaces
{
    public interface I3DTooltipTarget : ITooltipTargetBase
    { 
        void OnMouseEnter(); 
        void OnMouseExit();
    }
}