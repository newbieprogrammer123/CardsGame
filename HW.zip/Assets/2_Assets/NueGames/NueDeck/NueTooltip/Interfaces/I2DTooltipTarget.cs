﻿using UnityEngine.EventSystems;

namespace NueGames.NueDeck.ThirdParty.NueTooltip.Interfaces
{
    public interface I2DTooltipTarget :IPointerEnterHandler,IPointerExitHandler,ITooltipTargetBase
    {
        
    }
}