﻿namespace NueGames.NueDeck.ThirdParty.NueTooltip.CursorSystem
{
    public enum CursorType
    {
        Default,
        DefaultClicked
    }
}