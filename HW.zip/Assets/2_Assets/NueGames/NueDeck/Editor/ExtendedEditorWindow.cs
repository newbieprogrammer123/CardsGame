﻿using UnityEditor;

namespace NueGames.NueDeck.Editor
{
    public class ExtendedEditorWindow : EditorWindow
    {
      
    }
}